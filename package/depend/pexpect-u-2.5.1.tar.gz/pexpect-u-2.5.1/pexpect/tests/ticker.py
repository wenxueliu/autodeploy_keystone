#!/usr/bin/env python

import time, sys

for i in range(5):
  print "tick"
  time.sleep(1)

sys.exit(0)
