------------------
Option Definitions
------------------

.. currentmodule:: oslo.config.cfg

.. autoclass:: Opt
.. autoclass:: StrOpt
.. autoclass:: BoolOpt
.. autoclass:: IntOpt
.. autoclass:: FloatOpt
.. autoclass:: ListOpt
.. autoclass:: DictOpt
.. autoclass:: MultiStrOpt
.. autoclass:: DeprecatedOpt
.. autoclass:: SubCommandOpt
.. autoclass:: OptGroup
